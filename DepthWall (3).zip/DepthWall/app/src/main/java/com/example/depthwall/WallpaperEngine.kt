package com.example.depthwall

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas

/** Запасной вариант без анимации: две обычные картинки (блокировка и главный). */
object WallpaperEngine {

    fun applyStatic(
        context: Context,
        lockBitmap: Bitmap,
        homeBitmap: Bitmap,
        lockScale: Float,
        bgColor: Int,
    ) {
        val wm = WallpaperManager.getInstance(context)
        wm.setBitmap(homeBitmap, null, true, WallpaperManager.FLAG_SYSTEM)
        val lock = if (lockScale >= 0.999f) lockBitmap else shrink(lockBitmap, lockScale, bgColor)
        wm.setBitmap(lock, null, true, WallpaperManager.FLAG_LOCK)
    }

    private fun shrink(src: Bitmap, scale: Float, bg: Int): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawColor(bg)
        c.save()
        c.scale(scale, scale, src.width / 2f, src.height / 2f)
        c.drawBitmap(src, 0f, 0f, null)
        c.restore()
        return out
    }
}
