package com.example.depthwall

import android.animation.ValueAnimator
import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Paint
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import android.view.animation.DecelerateInterpolator
import androidx.core.content.ContextCompat

/**
 * Живые обои: на экране блокировки показывается форма с эффектом глубины
 * (уменьшенная на lockScale). При разблокировке картинка плавно увеличивается
 * до 100% и раскрывается на весь экран. При выключении экрана всё возвращается.
 */
class DepthWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = DepthWallEngine()

    inner class DepthWallEngine : Engine() {
        private val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        private var lockBmp: Bitmap? = null
        private var homeBmp: Bitmap? = null
        private var lockScale = 1f
        private var bg = Color.BLACK
        private var w = 0
        private var h = 0
        private var loadedVersion = -1L
        private var progress = 0f // 0 = экран блокировки, 1 = главный экран
        private var animator: ValueAnimator? = null

        private val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                when (intent.action) {
                    Intent.ACTION_SCREEN_OFF -> {
                        animator?.cancel()
                        progress = 0f
                        draw()
                    }
                    Intent.ACTION_USER_PRESENT -> animateTo(1f)
                }
            }
        }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_USER_PRESENT)
            }
            ContextCompat.registerReceiver(
                this@DepthWallpaperService, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED
            )
        }

        override fun onDestroy() {
            animator?.cancel()
            try { unregisterReceiver(receiver) } catch (_: Exception) {}
            super.onDestroy()
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            w = width
            h = height
            loadedVersion = -1L
            reloadIfNeeded()
            syncState()
            draw()
        }

        override fun onVisibilityChanged(visible: Boolean) {
            if (visible) {
                reloadIfNeeded()
                syncState()
                draw()
            }
        }

        private fun syncState() {
            if (animator?.isRunning == true) return
            progress = if (isPreview) 0f else {
                val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
                if (km.isKeyguardLocked) 0f else 1f
            }
        }

        private fun reloadIfNeeded() {
            if (w == 0 || h == 0) return
            val v = WallpaperStore.version(this@DepthWallpaperService)
            if (v == loadedVersion) return
            loadedVersion = v
            val ctx = this@DepthWallpaperService
            lockScale = WallpaperStore.lockScale(ctx)
            bg = WallpaperStore.bg(ctx)
            lockBmp = BitmapFactory.decodeFile(WallpaperStore.lockFile(ctx).path)
                ?.let { Bitmap.createScaledBitmap(it, w, h, true) }
            homeBmp = BitmapFactory.decodeFile(WallpaperStore.homeFile(ctx).path)
                ?.let { Bitmap.createScaledBitmap(it, w, h, true) }
        }

        private fun animateTo(target: Float) {
            animator?.cancel()
            animator = ValueAnimator.ofFloat(progress, target).apply {
                duration = 450
                interpolator = DecelerateInterpolator()
                addUpdateListener {
                    progress = it.animatedValue as Float
                    draw()
                }
                start()
            }
        }

        private fun draw() {
            if (w == 0 || h == 0) return
            val holder = surfaceHolder
            val canvas = try { holder.lockCanvas() } catch (_: Exception) { null } ?: return
            try {
                canvas.drawColor(bg)
                val t = progress.coerceIn(0f, 1f)
                val cx = w / 2f
                val cy = h / 2f

                // Главный экран: фото раскрывается на весь экран
                homeBmp?.let {
                    val s = 1.08f - 0.08f * t
                    paint.alpha = (255 * t).toInt()
                    canvas.save()
                    canvas.scale(s, s, cx, cy)
                    canvas.drawBitmap(it, 0f, 0f, paint)
                    canvas.restore()
                }
                // Экран блокировки: форма (уменьшена) растёт до 100% и растворяется
                lockBmp?.let {
                    val s = lockScale + (1f - lockScale) * t
                    paint.alpha = (255 * (1f - t)).toInt()
                    canvas.save()
                    canvas.scale(s, s, cx, cy)
                    canvas.drawBitmap(it, 0f, 0f, paint)
                    canvas.restore()
                }
            } finally {
                try { holder.unlockCanvasAndPost(canvas) } catch (_: Exception) {}
            }
        }
    }
}
