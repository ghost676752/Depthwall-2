package com.example.depthwall

import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * All shapes are generated as a androidx.compose.ui.graphics.Path inside a square
 * bounding box so they can be reused both for Compose clipping (preview) and for
 * building an Android Region/Path when compositing the final wallpaper bitmap.
 */
enum class WallShape(val label: String) {
    CIRCLE("Круг"),
    SQUIRCLE("Скруглённый"),
    COOKIE("Печенье"),
    FLOWER("Цветок");
}

fun buildShapePath(shape: WallShape, sizePx: Float): Path {
    return when (shape) {
        WallShape.CIRCLE -> circlePath(sizePx)
        WallShape.SQUIRCLE -> squirclePath(sizePx)
        WallShape.COOKIE -> scallopPath(sizePx, bumps = 12, amplitude = 0.035f)
        WallShape.FLOWER -> scallopPath(sizePx, bumps = 7, amplitude = 0.16f)
    }
}

private fun circlePath(size: Float): Path = Path().apply {
    addOval(androidx.compose.ui.geometry.Rect(0f, 0f, size, size))
}

private fun squirclePath(size: Float): Path {
    val r = size * 0.18f
    return Path().apply {
        addRoundRect(
            androidx.compose.ui.geometry.RoundRect(
                androidx.compose.ui.geometry.Rect(0f, 0f, size, size),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(r, r)
            )
        )
    }
}

/** Generic "wobbly circle" generator used for both Cookie (many small bumps)
 *  and Flower (fewer, deeper bumps) shapes. */
private fun scallopPath(size: Float, bumps: Int, amplitude: Float): Path {
    val cx = size / 2f
    val cy = size / 2f
    val baseR = size / 2f * (1f - amplitude)
    val path = Path()
    val points = 360
    for (i in 0..points) {
        val t = i.toDouble() / points
        val angle = t * 2.0 * PI
        val wobble = 1f + amplitude * cos(bumps * angle).toFloat()
        val r = baseR * wobble
        val x = cx + r * cos(angle).toFloat()
        val y = cy + r * sin(angle).toFloat()
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    path.close()
    return path
}

fun DrawScope.shapeSizePx(sizeFraction: Float): Float =
    min(size.width, size.height) * sizeFraction
