package com.example.depthwall

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.max

object DepthEngine {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

    private val segmenter by lazy {
        val options = SelfieSegmenterOptions.Builder()
            .setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE)
            .enableRawSizeMask()
            .build()
        Segmentation.getClient(options)
    }

    /** Цвет фона под цвет фото (тёмный оттенок среднего цвета). */
    fun backgroundColor(photo: Bitmap): Int {
        val px = Bitmap.createScaledBitmap(photo, 1, 1, true).getPixel(0, 0)
        val hsv = FloatArray(3)
        Color.colorToHSV(px, hsv)
        hsv[1] = (hsv[1] * 1.1f).coerceAtMost(1f)
        hsv[2] = (hsv[2] * 0.55f).coerceIn(0.15f, 0.6f)
        return Color.HSVToColor(hsv)
    }

    /** true, если у картинки есть настоящая прозрачность (PNG без фона). */
    fun hasTransparency(photo: Bitmap): Boolean {
        if (!photo.hasAlpha()) return false
        val small = Bitmap.createScaledBitmap(photo, 64, 64, true)
        var transparent = 0
        for (y in 0 until 64) for (x in 0 until 64) {
            if (Color.alpha(small.getPixel(x, y)) < 250) transparent++
        }
        return transparent > 64 * 64 * 0.02
    }

    /**
     * Маска объекта. Если фото уже PNG с прозрачным фоном — берём его прозрачность.
     * Иначе ML Kit (он рассчитан на реальных людей, на аниме работает плохо).
     */
    suspend fun subjectMask(photo: Bitmap): Bitmap {
        if (hasTransparency(photo)) return photo
        return suspendCancellableCoroutine { cont ->
            val input = InputImage.fromBitmap(photo, 0)
            segmenter.process(input)
                .addOnSuccessListener { result ->
                    val buf = result.buffer
                    val w = result.width
                    val h = result.height
                    buf.rewind()
                    val pixels = IntArray(w * h)
                    for (i in 0 until w * h) {
                        val a = (buf.float * 255).toInt().coerceIn(0, 255)
                        pixels[i] = a shl 24
                    }
                    val mask = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    mask.setPixels(pixels, 0, w, 0, 0, w, h)
                    cont.resume(Bitmap.createScaledBitmap(mask, photo.width, photo.height, true))
                }
                .addOnFailureListener { e -> cont.resumeWithException(e) }
        }
    }

    /**
     * Экран блокировки: фото внутри формы + объект, выходящий за край формы.
     * Фото и вырезанный объект рисуются в ОДНОМ месте и масштабе, поэтому
     * объект просто «не обрезается» формой там, где он выходит за её границы.
     */
    fun composeLock(
        photo: Bitmap,
        mask: Bitmap?,
        shapePath: Path,        // уже сдвинут в нужное место холста
        cx: Float, cy: Float,   // центр формы
        shapeSize: Float,
        w: Int, h: Int,
        shapeZoom: Float,
        overflow: Float,
        bgColor: Int,
    ): Bitmap {
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        canvas.drawColor(bgColor)
        drawPlaced(canvas, photo, cx, cy, shapeSize, shapeZoom, shapePath)
        if (mask != null) {
            val subject = applyMask(photo, mask)
            drawPlaced(canvas, subject, cx, cy, shapeSize, shapeZoom * overflow, null)
        }
        return out
    }

    /** Главный экран: фото раскрыто на весь экран. */
    fun composeHome(photo: Bitmap, w: Int, h: Int, bgColor: Int): Bitmap {
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        canvas.drawColor(bgColor)
        val scale = max(w.toFloat() / photo.width, h.toFloat() / photo.height)
        val m = Matrix()
        m.postScale(scale, scale)
        m.postTranslate((w - photo.width * scale) / 2f, (h - photo.height * scale) / 2f)
        canvas.drawBitmap(photo, m, paint)
        return out
    }

    private fun drawPlaced(
        canvas: Canvas, bmp: Bitmap, cx: Float, cy: Float,
        box: Float, zoom: Float, clip: Path?
    ) {
        val scale = max(box / bmp.width, box / bmp.height) * zoom
        val m = Matrix()
        m.postScale(scale, scale)
        m.postTranslate(cx - bmp.width * scale / 2f, cy - bmp.height * scale / 2f)
        canvas.save()
        if (clip != null) canvas.clipPath(clip)
        canvas.drawBitmap(bmp, m, paint)
        canvas.restore()
    }

    private fun applyMask(photo: Bitmap, mask: Bitmap): Bitmap {
        val result = Bitmap.createBitmap(photo.width, photo.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        canvas.drawBitmap(photo, 0f, 0f, null)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
        }
        canvas.drawBitmap(mask, 0f, 0f, p)
        return result
    }
}
