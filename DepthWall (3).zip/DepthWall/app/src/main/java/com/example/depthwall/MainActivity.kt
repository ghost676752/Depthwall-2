package com.example.depthwall

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asAndroidPath
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { DepthWallScreen() } }
    }
}

private class Built(val lock: Bitmap, val home: Bitmap, val bg: Int)

@Composable
fun DepthWallScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var photo by remember { mutableStateOf<Bitmap?>(null) }
    var shape by remember { mutableStateOf(WallShape.CIRCLE) }
    var shapeSizeFraction by remember { mutableFloatStateOf(0.55f) }
    var shapeZoom by remember { mutableFloatStateOf(1.0f) }
    var depthEnabled by remember { mutableStateOf(true) }
    var subjectOverflow by remember { mutableFloatStateOf(1.12f) }
    var lockScreenScale by remember { mutableFloatStateOf(1.0f) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }

    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { photo = loadBitmap(context, it) }
    }

    suspend fun build(src: Bitmap): Built = withContext(Dispatchers.Default) {
        val dm = context.resources.displayMetrics
        val w = dm.widthPixels
        val h = dm.heightPixels
        val bg = DepthEngine.backgroundColor(src)
        val size = w * shapeSizeFraction
        val cx = w / 2f
        val cy = h * 0.55f
        val path = buildShapePath(shape, size).asAndroidPath()
        path.transform(Matrix().apply { postTranslate(cx - size / 2f, cy - size / 2f) })
        val mask = if (depthEnabled) DepthEngine.subjectMask(src) else null
        val lock = DepthEngine.composeLock(
            src, mask, path, cx, cy, size, w, h, shapeZoom,
            if (depthEnabled) subjectOverflow else 1f, bg
        )
        val home = DepthEngine.composeHome(src, w, h, bg)
        Built(lock, home, bg)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0E0E12))
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("DepthWall", style = MaterialTheme.typography.headlineMedium, color = Color.White)
        Spacer(Modifier.height(4.dp))
        Text(
            "Форма с глубиной + плавный переход при разблокировке",
            color = Color.Gray, style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(16.dp))

        Box(
            modifier = Modifier
                .width(220.dp).height(460.dp)
                .clip(RoundedCornerShape(28.dp))
                .background(Color(0xFF2A3F6B)),
            contentAlignment = Alignment.Center
        ) {
            val p = photo
            if (p != null) {
                Box(
                    modifier = Modifier
                        .size(170.dp)
                        .graphicsLayer {
                            scaleX = shapeSizeFraction / 0.55f
                            scaleY = shapeSizeFraction / 0.55f
                        }
                        .clip(GenericShape { size, _ -> addPath(buildShapePath(shape, size.width)) })
                ) {
                    Image(
                        bitmap = p.asImageBitmap(), contentDescription = null,
                        modifier = Modifier.fillMaxSize().graphicsLayer {
                            scaleX = shapeZoom; scaleY = shapeZoom
                        }
                    )
                }
            } else {
                Text("Нет фото", color = Color.White.copy(alpha = 0.6f))
            }
        }

        Spacer(Modifier.height(12.dp))
        Button(onClick = { pickImage.launch("image/*") }) { Text("Выбрать фото") }
        Text(
            "Для эффекта глубины лучше PNG без фона (прозрачный фон). " +
                "Автовырезание рассчитано на реальных людей, на рисунках работает плохо.",
            color = Color.Gray, style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(top = 6.dp)
        )

        Spacer(Modifier.height(16.dp))
        Text("Форма", color = Color.White, modifier = Modifier.align(Alignment.Start))
        Spacer(Modifier.height(8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(WallShape.values()) { s ->
                FilterChip(selected = shape == s, onClick = { shape = s }, label = { Text(s.label) })
            }
        }

        LabeledSlider("Размер формы", shapeSizeFraction, 0.25f..0.9f) { shapeSizeFraction = it }
        LabeledSlider("Приближение фото в форме", shapeZoom, 0.7f..2.5f) { shapeZoom = it }

        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Эффект глубины (объект выходит за форму)", color = Color.White, modifier = Modifier.weight(1f))
            Switch(checked = depthEnabled, onCheckedChange = { depthEnabled = it })
        }
        if (depthEnabled) {
            LabeledSlider("Насколько объект выступает", subjectOverflow, 1.0f..1.4f) { subjectOverflow = it }
        }
        LabeledSlider(
            "Размер обоев на блокировке (после разблокировки плавно вернётся к 100%)",
            lockScreenScale, 0.5f..1.0f
        ) { lockScreenScale = it }

        Spacer(Modifier.height(20.dp))

        Button(
            enabled = photo != null && !busy,
            onClick = {
                val src = photo ?: return@Button
                busy = true; status = null
                scope.launch {
                    try {
                        val b = build(src)
                        withContext(Dispatchers.IO) {
                            WallpaperStore.save(context, b.lock, b.home, lockScreenScale, b.bg)
                        }
                        val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(
                            WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                            ComponentName(context, DepthWallpaperService::class.java)
                        )
                        context.startActivity(i)
                        status = "Нажми «Установить» в открывшемся окне"
                    } catch (e: Exception) {
                        status = "Ошибка: ${e.message}"
                    } finally { busy = false }
                }
            }
        ) { Text(if (busy) "Обработка..." else "Установить живые обои (с анимацией)") }

        Spacer(Modifier.height(8.dp))
        OutlinedButton(
            enabled = photo != null && !busy,
            onClick = {
                val src = photo ?: return@OutlinedButton
                busy = true; status = null
                scope.launch {
                    try {
                        val b = build(src)
                        withContext(Dispatchers.IO) {
                            WallpaperEngine.applyStatic(context, b.lock, b.home, lockScreenScale, b.bg)
                        }
                        status = "Обои установлены (без анимации)"
                    } catch (e: Exception) {
                        status = "Ошибка: ${e.message}"
                    } finally { busy = false }
                }
            }
        ) { Text("Установить без анимации") }

        status?.let { Spacer(Modifier.height(8.dp)); Text(it, color = Color.White) }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun LabeledSlider(
    label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit
) {
    Column(Modifier.fillMaxWidth().padding(top = 12.dp)) {
        Text(label, color = Color.White, style = MaterialTheme.typography.bodySmall)
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}

/** Загружает фото, уменьшая огромные до ~2048 пикселей, чтобы не кончилась память. */
private fun loadBitmap(context: Context, uri: Uri): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    var sample = 1
    while (max(bounds.outWidth, bounds.outHeight) / sample > 2048) sample *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
    return context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
}
