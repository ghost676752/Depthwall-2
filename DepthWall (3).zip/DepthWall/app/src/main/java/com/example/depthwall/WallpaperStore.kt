package com.example.depthwall

import android.content.Context
import android.graphics.Bitmap
import java.io.File

/** Хранит готовые картинки и настройки для живых обоев. */
object WallpaperStore {
    private const val PREFS = "depthwall"

    fun lockFile(c: Context) = File(c.filesDir, "lock.png")
    fun homeFile(c: Context) = File(c.filesDir, "home.png")

    fun save(c: Context, lock: Bitmap, home: Bitmap, lockScale: Float, bg: Int) {
        lockFile(c).outputStream().use { lock.compress(Bitmap.CompressFormat.PNG, 100, it) }
        homeFile(c).outputStream().use { home.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putFloat("lockScale", lockScale)
            .putInt("bg", bg)
            .putLong("version", System.currentTimeMillis())
            .apply()
    }

    fun lockScale(c: Context) =
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getFloat("lockScale", 1f)

    fun bg(c: Context) =
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt("bg", 0xFF000000.toInt())

    fun version(c: Context) =
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong("version", 0L)
}
