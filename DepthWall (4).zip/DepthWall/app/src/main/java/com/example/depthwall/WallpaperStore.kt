package com.example.depthwall

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File

class Loaded(val photo: Bitmap, val subject: Bitmap?, val params: WallParams, val version: Long)

/** Сохраняет фото, вырезанный объект и настройки для живых обоев. */
object WallpaperStore {
    private const val PREFS = "depthwall"
    private fun photoFile(c: Context) = File(c.filesDir, "photo.png")
    private fun subjectFile(c: Context) = File(c.filesDir, "subject.png")
    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun save(c: Context, photo: Bitmap, subject: Bitmap?, p: WallParams) {
        photoFile(c).outputStream().use { photo.compress(Bitmap.CompressFormat.PNG, 100, it) }
        if (subject != null) {
            subjectFile(c).outputStream().use { subject.compress(Bitmap.CompressFormat.PNG, 100, it) }
        } else {
            subjectFile(c).delete()
        }
        prefs(c).edit()
            .putString("shape", p.shape.name)
            .putFloat("cx", p.cx).putFloat("cy", p.cy)
            .putFloat("size", p.sizeFrac)
            .putFloat("zoom", p.zoom)
            .putFloat("overflow", p.overflow)
            .putInt("bg", p.bg)
            .putLong("version", System.currentTimeMillis())
            .apply()
    }

    fun version(c: Context) = prefs(c).getLong("version", 0L)

    fun load(c: Context): Loaded? {
        val photo = BitmapFactory.decodeFile(photoFile(c).path) ?: return null
        val subject = if (subjectFile(c).exists()) BitmapFactory.decodeFile(subjectFile(c).path) else null
        val pr = prefs(c)
        val shape = try {
            WallShape.valueOf(pr.getString("shape", WallShape.CIRCLE.name)!!)
        } catch (_: Exception) { WallShape.CIRCLE }
        val params = WallParams(
            shape, pr.getFloat("cx", 0.5f), pr.getFloat("cy", 0.42f),
            pr.getFloat("size", 0.55f), pr.getFloat("zoom", 1f),
            pr.getFloat("overflow", 1.12f), pr.getInt("bg", 0xFF2A3F6B.toInt())
        )
        return Loaded(photo, subject, params, pr.getLong("version", 0L))
    }
}
