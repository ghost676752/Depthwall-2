package com.example.depthwall

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Подготовка картинок: цвет фона и вырезание объекта для эффекта глубины. */
object DepthEngine {

    private val segmenter by lazy {
        val options = SelfieSegmenterOptions.Builder()
            .setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE)
            .enableRawSizeMask()
            .build()
        Segmentation.getClient(options)
    }

    fun backgroundColor(photo: Bitmap): Int {
        val px = Bitmap.createScaledBitmap(photo, 1, 1, true).getPixel(0, 0)
        val hsv = FloatArray(3)
        Color.colorToHSV(px, hsv)
        hsv[1] = (hsv[1] * 1.1f).coerceAtMost(1f)
        hsv[2] = (hsv[2] * 0.55f).coerceIn(0.2f, 0.65f)
        return Color.HSVToColor(hsv)
    }

    fun hasTransparency(photo: Bitmap): Boolean {
        if (!photo.hasAlpha()) return false
        val small = Bitmap.createScaledBitmap(photo, 64, 64, true)
        var transparent = 0
        for (y in 0 until 64) for (x in 0 until 64) {
            if (Color.alpha(small.getPixel(x, y)) < 250) transparent++
        }
        return transparent > 64 * 64 * 0.02
    }

    /** Объект, вырезанный из фото (остальное прозрачное), того же размера, что и фото. */
    suspend fun subjectCutout(photo: Bitmap): Bitmap {
        if (hasTransparency(photo)) return photo   // PNG без фона — уже готово
        val mask = segment(photo)
        val result = Bitmap.createBitmap(photo.width, photo.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        canvas.drawBitmap(photo, 0f, 0f, null)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
        }
        canvas.drawBitmap(mask, 0f, 0f, p)
        return result
    }

    private suspend fun segment(photo: Bitmap): Bitmap = suspendCancellableCoroutine { cont ->
        val input = InputImage.fromBitmap(photo, 0)
        segmenter.process(input)
            .addOnSuccessListener { result ->
                val buf = result.buffer
                val w = result.width
                val h = result.height
                buf.rewind()
                val pixels = IntArray(w * h)
                for (i in 0 until w * h) {
                    val a = (buf.float * 255).toInt().coerceIn(0, 255)
                    pixels[i] = a shl 24
                }
                val mask = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                mask.setPixels(pixels, 0, w, 0, 0, w, h)
                cont.resume(Bitmap.createScaledBitmap(mask, photo.width, photo.height, true))
            }
            .addOnFailureListener { e -> cont.resumeWithException(e) }
    }
}
