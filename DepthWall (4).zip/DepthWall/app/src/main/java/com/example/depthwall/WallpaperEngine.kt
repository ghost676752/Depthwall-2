package com.example.depthwall

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas

/** Запасной вариант без анимации: обычные картинки для блокировки и главного экрана. */
object WallpaperEngine {
    fun applyStatic(context: Context, photo: Bitmap, subject: Bitmap?, p: WallParams) {
        val dm = context.resources.displayMetrics
        val w = dm.widthPixels
        val h = dm.heightPixels
        val r = DepthRenderer()
        val lock = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        r.draw(Canvas(lock), w, h, photo, subject, p, 0f)
        val home = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        r.draw(Canvas(home), w, h, photo, subject, p, 1f)
        val wm = WallpaperManager.getInstance(context)
        wm.setBitmap(home, null, true, WallpaperManager.FLAG_SYSTEM)
        wm.setBitmap(lock, null, true, WallpaperManager.FLAG_LOCK)
    }
}
