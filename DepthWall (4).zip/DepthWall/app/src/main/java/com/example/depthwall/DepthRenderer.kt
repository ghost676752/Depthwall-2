package com.example.depthwall

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import androidx.compose.ui.graphics.asAndroidPath
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.pow

/** Все настройки обоев. cx/cy — центр формы в долях экрана (0..1), sizeFrac — доля ширины. */
class WallParams(
    val shape: WallShape,
    val cx: Float,
    val cy: Float,
    val sizeFrac: Float,
    val zoom: Float,      // приближение (>1) или уменьшение (<1) фото внутри формы
    val overflow: Float,  // насколько объект выступает за форму
    val bg: Int,
)

/**
 * Один и тот же код рисует и предпросмотр в приложении, и сами обои.
 * t = 0: экран блокировки (форма с фото внутри).
 * t = 1: главный экран (фото на весь экран).
 * Между ними форма растёт, пока не накроет весь экран, а масштаб фото
 * возвращается к 100% — как в DropWall.
 */
class DepthRenderer {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private var cachedShape: WallShape? = null
    private var cachedSize = -1f
    private var cachedPath: Path? = null

    private fun basePath(shape: WallShape, size: Float): Path {
        val cached = cachedPath
        if (cached != null && cachedShape == shape && cachedSize == size) return cached
        val p = Path(buildShapePath(shape, size).asAndroidPath())
        cachedPath = p
        cachedShape = shape
        cachedSize = size
        return p
    }

    private fun photoMatrix(photo: Bitmap, w: Int, h: Int, cx: Float, cy: Float, zoom: Float): Matrix {
        val cover = max(w.toFloat() / photo.width, h.toFloat() / photo.height)
        val m = Matrix()
        m.postScale(cover, cover)
        m.postTranslate((w - photo.width * cover) / 2f, (h - photo.height * cover) / 2f)
        m.postScale(zoom, zoom, cx, cy)
        return m
    }

    fun draw(
        canvas: Canvas, w: Int, h: Int,
        photo: Bitmap, subject: Bitmap?, p: WallParams, t: Float
    ) {
        if (w <= 0 || h <= 0) return
        val tt = t.coerceIn(0f, 1f)
        val cx = p.cx * w
        val cy = p.cy * h
        canvas.drawColor(p.bg)

        if (tt >= 0.999f) {
            canvas.drawBitmap(photo, photoMatrix(photo, w, h, cx, cy, 1f), paint)
            return
        }

        val size = p.sizeFrac * w
        val reach = hypot(max(cx, w - cx), max(cy, h - cy))
        val maxScale = reach / (0.34f * size) * 1.03f
        val ease = tt * tt * (3f - 2f * tt)
        val s = maxScale.pow(ease)                 // форма растёт
        val z = p.zoom + (1f - p.zoom) * ease      // масштаб фото возвращается к 100%

        val path = Path(basePath(p.shape, size))
        val pm = Matrix()
        pm.postTranslate(-size / 2f, -size / 2f)
        pm.postScale(s, s)
        pm.postTranslate(cx, cy)
        path.transform(pm)

        canvas.save()
        canvas.clipPath(path)
        canvas.drawBitmap(photo, photoMatrix(photo, w, h, cx, cy, z), paint)
        canvas.restore()

        if (subject != null) {
            val ov = p.overflow + (1f - p.overflow) * ease
            canvas.drawBitmap(subject, photoMatrix(subject, w, h, cx, cy, z * ov), paint)
        }
    }
}
