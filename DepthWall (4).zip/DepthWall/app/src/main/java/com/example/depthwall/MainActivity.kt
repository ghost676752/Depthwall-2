package com.example.depthwall

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { DepthWallScreen() } }
    }
}

private val BG_CHOICES = listOf(0xFF4C7BD9, 0xFF2EC4B6, 0xFFFFBE4A, 0xFFF46B9E, 0xFF9B7BFF, 0xFFE6E0D9, 0xFF1F2430)

@Composable
fun DepthWallScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val dm = context.resources.displayMetrics
    val aspect = dm.widthPixels.toFloat() / dm.heightPixels.toFloat()

    var photo by remember { mutableStateOf<Bitmap?>(null) }
    var subject by remember { mutableStateOf<Bitmap?>(null) }
    var shape by remember { mutableStateOf(WallShape.CIRCLE) }
    var cx by remember { mutableFloatStateOf(0.5f) }
    var cy by remember { mutableFloatStateOf(0.42f) }
    var sizeFrac by remember { mutableFloatStateOf(0.55f) }
    var zoom by remember { mutableFloatStateOf(1.0f) }
    var depthEnabled by remember { mutableStateOf(true) }
    var overflow by remember { mutableFloatStateOf(1.12f) }
    var bgChoice by remember { mutableStateOf<Long?>(null) } // null = авто
    var unlocked by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }

    val t by animateFloatAsState(if (unlocked) 1f else 0f, tween(650), label = "unlock")

    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { photo = loadBitmap(context, it) }
    }

    // Вырезаем объект для эффекта глубины
    LaunchedEffect(photo, depthEnabled) {
        subject = null
        val p = photo
        if (p != null && depthEnabled) {
            subject = try {
                withContext(Dispatchers.Default) { DepthEngine.subjectCutout(p) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
        }
    }

    val autoBg = remember(photo) { photo?.let { DepthEngine.backgroundColor(it) } ?: 0xFF2A3F6B.toInt() }
    val bg = bgChoice?.toInt() ?: autoBg
    val params = WallParams(shape, cx, cy, sizeFrac, zoom, if (depthEnabled) overflow else 1f, bg)
    val renderer = remember { DepthRenderer() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0E0E12))
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("DepthWall", style = MaterialTheme.typography.headlineMedium, color = Color.White)
        Spacer(Modifier.height(12.dp))

        // ---------- Предпросмотр (тот же код рисования, что и в обоях) ----------
        val previewW = 230.dp
        Box(
            modifier = Modifier
                .width(previewW)
                .aspectRatio(aspect)
                .clip(RoundedCornerShape(28.dp))
                .background(Color(bg))
        ) {
            val p = photo
            if (p != null) {
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(Unit) {
                            detectDragGestures { change, drag ->
                                change.consume()
                                cx = (cx + drag.x / size.width).coerceIn(0.05f, 0.95f)
                                cy = (cy + drag.y / size.height).coerceIn(0.05f, 0.95f)
                            }
                        }
                ) {
                    drawIntoCanvas { c ->
                        renderer.draw(c.nativeCanvas, size.width.toInt(), size.height.toInt(), p, subject, params, t)
                    }
                }
                Text(
                    "12:30",
                    color = Color.White.copy(alpha = 0.6f),
                    fontSize = 44.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 28.dp)
                        .graphicsLayer { alpha = 1f - t }
                )
            } else {
                Text(
                    "Выбери фото", color = Color.White.copy(alpha = 0.7f),
                    modifier = Modifier.align(Alignment.Center)
                )
            }
        }

        Spacer(Modifier.height(10.dp))
        Text(
            "Перетащи форму пальцем по фото",
            color = Color.Gray, style = MaterialTheme.typography.bodySmall
        )
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Показать разблокировку (форма растёт на весь экран)", color = Color.White, modifier = Modifier.weight(1f))
            Switch(checked = unlocked, onCheckedChange = { unlocked = it })
        }

        Spacer(Modifier.height(8.dp))
        Button(onClick = { pickImage.launch("image/*") }) { Text(if (photo == null) "Выбрать фото" else "Другое фото") }
        Text(
            "Для эффекта глубины лучше PNG без фона. Автовырезание рассчитано на реальных людей, на рисунках работает плохо.",
            color = Color.Gray, style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 6.dp)
        )

        Spacer(Modifier.height(16.dp))
        Text("Форма", color = Color.White, modifier = Modifier.align(Alignment.Start))
        Spacer(Modifier.height(8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(WallShape.values()) { s ->
                FilterChip(selected = shape == s, onClick = { shape = s }, label = { Text(s.label) })
            }
        }

        Spacer(Modifier.height(12.dp))
        Text("Фон", color = Color.White, modifier = Modifier.align(Alignment.Start))
        Spacer(Modifier.height(8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Box(
                    Modifier.size(40.dp).clip(CircleShape).background(Color(autoBg))
                        .border(if (bgChoice == null) 3.dp else 0.dp, Color.White, CircleShape)
                        .clickable { bgChoice = null },
                    contentAlignment = Alignment.Center
                ) { Text("A", color = Color.White, fontWeight = FontWeight.Bold) }
            }
            items(BG_CHOICES) { c ->
                Box(
                    Modifier.size(40.dp).clip(CircleShape).background(Color(c))
                        .border(if (bgChoice == c) 3.dp else 0.dp, Color.White, CircleShape)
                        .clickable { bgChoice = c }
                )
            }
        }

        LabeledSlider("Размер формы", sizeFrac, 0.25f..0.95f) { sizeFrac = it }
        LabeledSlider(
            "Фото в форме: меньше ← 100% → больше (на главном экране вернётся к 100%)",
            zoom, 0.5f..2.5f
        ) { zoom = it }

        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Эффект глубины (объект выходит за форму)", color = Color.White, modifier = Modifier.weight(1f))
            Switch(checked = depthEnabled, onCheckedChange = { depthEnabled = it })
        }
        if (depthEnabled) {
            LabeledSlider("Насколько объект выступает", overflow, 1.0f..1.4f) { overflow = it }
        }

        Spacer(Modifier.height(20.dp))

        Button(
            enabled = photo != null && !busy,
            onClick = {
                val src = photo ?: return@Button
                busy = true; status = null
                scope.launch {
                    try {
                        withContext(Dispatchers.IO) { WallpaperStore.save(context, src, subject, params) }
                        val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(
                            WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                            ComponentName(context, DepthWallpaperService::class.java)
                        )
                        context.startActivity(i)
                        status = "Нажми «Установить» в открывшемся окне"
                    } catch (e: Exception) {
                        status = "Ошибка: ${e.message}"
                    } finally { busy = false }
                }
            }
        ) { Text("Установить живые обои (с анимацией)") }

        Spacer(Modifier.height(8.dp))
        OutlinedButton(
            enabled = photo != null && !busy,
            onClick = {
                val src = photo ?: return@OutlinedButton
                busy = true; status = null
                scope.launch {
                    try {
                        withContext(Dispatchers.IO) { WallpaperEngine.applyStatic(context, src, subject, params) }
                        status = "Обои установлены (без анимации)"
                    } catch (e: Exception) {
                        status = "Ошибка: ${e.message}"
                    } finally { busy = false }
                }
            }
        ) { Text("Установить без анимации") }

        status?.let { Spacer(Modifier.height(8.dp)); Text(it, color = Color.White) }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun LabeledSlider(
    label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit
) {
    Column(Modifier.fillMaxWidth().padding(top = 12.dp)) {
        Text(label, color = Color.White, style = MaterialTheme.typography.bodySmall)
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}

/** Загружает фото, уменьшая огромные до ~2048 пикселей, чтобы не кончилась память. */
private fun loadBitmap(context: Context, uri: Uri): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    var sample = 1
    while (max(bounds.outWidth, bounds.outHeight) / sample > 2048) sample *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
    return context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
}
