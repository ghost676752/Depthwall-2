package com.example.depthwall

import android.animation.ValueAnimator
import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.service.wallpaper.WallpaperService
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.animation.LinearInterpolator
import androidx.core.content.ContextCompat
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Живые обои. На блокировке — форма с фото. При разблокировке форма растёт
 * и накрывает весь экран. При выключении экрана всё возвращается.
 * В окне предпросмотра переход запускается нажатием на экран.
 */
class DepthWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = DepthWallEngine()

    inner class DepthWallEngine : Engine() {
        private val renderer = DepthRenderer()
        private var photo: Bitmap? = null
        private var subject: Bitmap? = null
        private var params: WallParams? = null
        private var w = 0
        private var h = 0
        private var loadedVersion = -1L
        private var progress = 0f
        private var animator: ValueAnimator? = null

        private val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                when (intent.action) {
                    Intent.ACTION_SCREEN_OFF -> {
                        animator?.cancel()
                        progress = 0f
                        draw()
                    }
                    Intent.ACTION_USER_PRESENT -> animateTo(1f)
                }
            }
        }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            setTouchEventsEnabled(true)
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_USER_PRESENT)
            }
            ContextCompat.registerReceiver(
                this@DepthWallpaperService, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED
            )
        }

        override fun onDestroy() {
            animator?.cancel()
            try { unregisterReceiver(receiver) } catch (_: Exception) {}
            super.onDestroy()
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            w = width
            h = height
            loadedVersion = -1L
            reloadIfNeeded()
            syncState()
            draw()
        }

        override fun onVisibilityChanged(visible: Boolean) {
            if (visible) {
                reloadIfNeeded()
                syncState()
                draw()
            }
        }

        override fun onTouchEvent(event: MotionEvent) {
            // Только в окне предпросмотра: нажатие запускает переход туда и обратно
            if (isPreview && event.action == MotionEvent.ACTION_UP) {
                animateTo(if (progress < 0.5f) 1f else 0f)
            }
        }

        private fun syncState() {
            if (animator?.isRunning == true) return
            progress = if (isPreview) 0f else {
                val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
                if (km.isKeyguardLocked) 0f else 1f
            }
        }

        private fun reloadIfNeeded() {
            if (w == 0 || h == 0) return
            val ctx = this@DepthWallpaperService
            val v = WallpaperStore.version(ctx)
            if (v == loadedVersion) return
            loadedVersion = v
            val loaded = WallpaperStore.load(ctx) ?: return
            params = loaded.params
            // Один раз подгоняем картинки под экран, чтобы анимация шла плавно
            val cover = max(w.toFloat() / loaded.photo.width, h.toFloat() / loaded.photo.height)
            val nw = (loaded.photo.width * cover).roundToInt().coerceAtLeast(1)
            val nh = (loaded.photo.height * cover).roundToInt().coerceAtLeast(1)
            photo = Bitmap.createScaledBitmap(loaded.photo, nw, nh, true)
            subject = loaded.subject?.let { Bitmap.createScaledBitmap(it, nw, nh, true) }
        }

        private fun animateTo(target: Float) {
            animator?.cancel()
            animator = ValueAnimator.ofFloat(progress, target).apply {
                duration = 650
                interpolator = LinearInterpolator()
                addUpdateListener {
                    progress = it.animatedValue as Float
                    draw()
                }
                start()
            }
        }

        private fun draw() {
            val ph = photo ?: return
            val pr = params ?: return
            if (w == 0 || h == 0) return
            val holder = surfaceHolder
            val canvas = try { holder.lockHardwareCanvas() } catch (_: Exception) {
                try { holder.lockCanvas() } catch (_: Exception) { null }
            } ?: return
            try {
                renderer.draw(canvas, w, h, ph, subject, pr, progress)
            } finally {
                try { holder.unlockCanvasAndPost(canvas) } catch (_: Exception) {}
            }
        }
    }
}
